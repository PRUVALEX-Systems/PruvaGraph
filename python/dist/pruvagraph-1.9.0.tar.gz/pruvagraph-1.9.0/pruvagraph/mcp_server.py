"""
PruvaGraph MCP Server — Universal IDE integration.

Exposes PruvaGraph's knowledge graph as Model Context Protocol (MCP) tools,
making it accessible from any MCP-compatible IDE:
  - Claude Code  (claude mcp add pruvagraph ...)
  - VS Code      (via Cline, Continue, or Claude Dev extension)
  - Cursor       (.cursor/mcp.json)
  - Windsurf     (mcp_config.json)
  - Any LLM tool supporting MCP

Tools exposed (v1.9.0 — 23 tools):
  1. query_graph           — Natural language query over the codebase graph.
  2. get_dependencies      — Find all dependencies of a module/function.
  3. find_callers          — Who calls a given function?
  4. get_summary           — One-sentence summary of any node.
  5. list_communities      — Show architectural clusters/modules.
  6. cost_report           — Show LLM cost savings from last run.
  7. get_graph_diff        — What changed since last build?
  8. analyze_impact        — What breaks if X changes? (blast radius)
  9. list_packages         — Monorepo: list packages + cross-package edges.
  10. remember             — Persist a decision/task/blocker across sessions.
  11. recall               — Retrieve all persisted session memory.
  12. validate_import      — DriftGuard: check if a module/symbol exists.
  13. scan_suggestion      — DriftGuard: scan a diff for invalid imports.
  14. get_active_context   — ContextLens: session summary + token breakdown.
  15. measure_token_usage  — ContextLens: per-tool token cost this session.
  16. trace_last_tool_calls— ContextLens: recent tool call history.
  17. create_checkpoint    — TaskWeaver: save agent step with git micro-commit.
  18. get_task_progress    — TaskWeaver: show checkpoint DAG for a task.
  19. rollback_to_checkpoint— TaskWeaver: advisory rollback with git command.
  20. list_checkpoints     — TaskWeaver: list all checkpoints.
  21. check_budget         — BudgetGovernor: remaining token budget this session.
  22. get_applicable_rules — RulesForge: context-aware rules for the current file.
  23. learn_from_accept    — RulesForge: capture a rule from an accepted AI suggestion.

Running the server:
    python -m pruvagraph.mcp_server            # stdio transport (Claude Code)
    python -m pruvagraph.mcp_server --http     # HTTP transport (VS Code / Cursor)

Installing:
    pruvagraph install --claude-code           # Writes ~/.claude/mcp_config.json
    pruvagraph install --cursor               # Writes .cursor/mcp.json
    pruvagraph install --vscode               # Writes .vscode/mcp.json

Requires: pip install mcp  (Model Context Protocol SDK, free, MIT license)
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Settings-gating: PRUVAGRAPH_DISABLED_MODULES env var
# ---------------------------------------------------------------------------
# VS Code extension reads workspace settings (pruvagraph.modules.X.enabled)
# and passes disabled module names via this env var when spawning the server.
# Format: comma-separated module keys, e.g. "taskweaver,rulesforge"
# Each key maps to a set of MCP tool names (see _MODULE_TOOLS below).
# This is the ONLY way to conditionally disable server-side modules because
# the MCP server runs as a separate subprocess outside VS Code's API.

_raw_disabled = os.environ.get("PRUVAGRAPH_DISABLED_MODULES", "").strip()
_DISABLED_MODULES: frozenset[str] = (
    frozenset(m.strip().lower() for m in _raw_disabled.split(",") if m.strip())
    if _raw_disabled else frozenset()
)

# Map: settings key → MCP tool names that belong to that module
_MODULE_TOOLS: dict[str, list[str]] = {
    "ghostmemory":   ["remember", "recall"],
    "driftguard":    ["validate_import", "scan_suggestion"],
    "contextlens":   ["get_active_context", "measure_token_usage", "trace_last_tool_calls"],
    "taskweaver":    ["create_checkpoint", "get_task_progress", "rollback_to_checkpoint", "list_checkpoints"],
    "budgetgovernor": ["check_budget"],
    "rulesforge":    ["get_applicable_rules", "learn_from_accept"],
}

# Build set of tool names that are gated off right now
_DISABLED_TOOLS: frozenset[str] = frozenset(
    tool
    for module_key, tools in _MODULE_TOOLS.items()
    if module_key in _DISABLED_MODULES
    for tool in tools
)

if _DISABLED_TOOLS:
    _disabled_str = ", ".join(sorted(_DISABLED_TOOLS))
    print(
        f"[pruvagraph] Settings-gating: disabled modules={_DISABLED_MODULES!r} "
        f"→ tools excluded: {_disabled_str}",
        file=sys.stderr,
    )

# Gap 2 — session-level read tracker (in-process, lives for MCP server lifetime)
try:
    from pruvagraph import session_tracker as _st
    _SESSION_TRACKING = True
except ImportError:
    _SESSION_TRACKING = False


# ---------------------------------------------------------------------------
# MCP SDK (pip install mcp)
# ---------------------------------------------------------------------------
try:
    from mcp.server import Server
    from mcp.server.models import InitializationOptions
    from mcp.server.lowlevel.server import NotificationOptions
    from mcp.server.stdio import stdio_server
    from mcp.types import (
        CallToolRequest,
        CallToolResult,
        ListToolsRequest,
        ListToolsResult,
        TextContent,
        Tool,
    )
    _MCP_AVAILABLE = True
except ImportError:
    _MCP_AVAILABLE = False


# ---------------------------------------------------------------------------
# Graph loader (lazy, cached) — Arch1 streaming-aware
# ---------------------------------------------------------------------------

_graph_cache: dict[str, Any] = {}

def _load_graph(root: str = ".") -> tuple[Any, bool]:
    """
    Load best available networkx graph.
    Prefers full graph.json, falls back to graph_partial.json during streaming build.

    Returns (graph, is_partial). Returns (None, False) if no graph available.
    """
    out_dir = Path(root) / "pruvagraph-out"
    try:
        from pruvagraph.streaming import load_best_graph
        return load_best_graph(out_dir)
    except ImportError:
        pass

    # Fallback to direct load
    graph_path = out_dir / "graph.json"
    if not graph_path.exists():
        return None, False

    import networkx as nx
    G = nx.node_link_graph(json.loads(graph_path.read_text()))
    return G, False


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------

def _query_graph(question: str, root: str = ".") -> str:
    """
    Query the graph using the full 5-tier cost pipeline (C1 fix).
    Replaces the old simple keyword search with the real query engine.
    """
    G, is_partial = _load_graph(root)
    if G is None:
        return "Please run pruvagraph . first to build the graph."

    prefix = ""
    if is_partial:
        try:
            from pruvagraph.streaming import get_build_status, partial_graph_note
            status = get_build_status(Path(root) / "pruvagraph-out")
            prefix = partial_graph_note(status.get("percent", 0))
        except Exception:
            pass

    # Use the full 5-tier pipeline from query.py (C1 fix)
    try:
        from pruvagraph.query import query
        out_dir = Path(root) / "pruvagraph-out"
        result = query(
            G,
            question,
            backend="none",
            out_dir=out_dir if out_dir.exists() else None,
        )
        return prefix + result
    except Exception as e:
        # Fallback: keyword search if query module fails
        q_lower = question.lower()
        matches = []
        for node_id, data in G.nodes(data=True):
            label   = str(data.get("label", "")).lower()
            summary = str(data.get("summary", "")).lower()
            if any(kw in label or kw in summary for kw in q_lower.split()):
                matches.append({
                    "id":      node_id,
                    "label":   data.get("label"),
                    "type":    data.get("type"),
                    "summary": data.get("summary"),
                    "file":    data.get("file"),
                })
        if not matches:
            return f"No nodes found matching: {question} (query engine error: {e})"
        lines = [f"Found {len(matches)} matching nodes:\n"]
        for m in matches[:10]:
            lines.append(f"• [{m['type']}] {m['label']} ({m['file']})\n  {m['summary']}")
        if len(matches) > 10:
            lines.append(f"\n... and {len(matches)-10} more.")
        return prefix + "\n".join(lines)


def _get_dependencies(node_id: str, root: str = ".") -> str:
    """Return all nodes that node_id imports/uses/calls."""
    # Gap 2: return terse back-reference if already served this session
    cache_key = f"deps::{node_id}"
    if _SESSION_TRACKING:
        ref = _st.already_seen(cache_key, tool="get_dependencies")
        if ref:
            return ref

    G, is_partial = _load_graph(root)
    if G is None:
        return "Please run pruvagraph . first to build the graph."

    if node_id not in G:
        return f"Node '{node_id}' not found in graph."

    deps = []
    for _, target, data in G.out_edges(node_id, data=True):
        target_data = G.nodes[target]
        deps.append({
            "relation": data.get("relation", "→"),
            "id":       target,
            "label":    target_data.get("label"),
            "summary":  target_data.get("summary", ""),
        })

    if not deps:
        return f"'{node_id}' has no outgoing dependencies."

    lines = [f"Dependencies of '{node_id}':\n"]
    for d in deps:
        lines.append(f"  {d['relation']} {d['label']} — {d['summary']}")
    ans = "\n".join(lines)
    if is_partial:
        ans = "[PARTIAL GRAPH - Build still running]\n" + ans

    if _SESSION_TRACKING:
        _st.record_seen(cache_key, tool="get_dependencies")
    return ans


def _find_callers(node_id: str, root: str = ".") -> str:
    """Return all nodes that call/import node_id."""
    # Gap 2: return terse back-reference if already served this session
    cache_key = f"callers::{node_id}"
    if _SESSION_TRACKING:
        ref = _st.already_seen(cache_key, tool="find_callers")
        if ref:
            return ref

    G, is_partial = _load_graph(root)
    if G is None:
        return "Please run pruvagraph . first to build the graph."

    if node_id not in G:
        return f"Node '{node_id}' not found in graph."

    callers = []
    for source, _, data in G.in_edges(node_id, data=True):
        source_data = G.nodes[source]
        callers.append({
            "relation": data.get("relation", "→"),
            "id":       source,
            "label":    source_data.get("label"),
            "file":     source_data.get("file", ""),
        })

    if not callers:
        return f"No callers found for '{node_id}'."

    lines = [f"Callers of '{node_id}':\n"]
    for c in callers:
        lines.append(f"  {c['label']} ({c['file']}) via {c['relation']}")
    ans = "\n".join(lines)
    if is_partial:
        ans = "[PARTIAL GRAPH - Build still running]\n" + ans

    if _SESSION_TRACKING:
        _st.record_seen(cache_key, tool="find_callers")
    return ans


def _get_summary(node_id: str, root: str = ".") -> str:
    """Get one-sentence summary and metadata for a node."""
    # Gap 2: return terse back-reference if already served this session
    if _SESSION_TRACKING:
        ref = _st.already_seen(node_id, tool="get_summary")
        if ref:
            return ref

    G, is_partial = _load_graph(root)
    if G is None:
        return "Please run pruvagraph . first to build the graph."

    # Fuzzy match by label if exact ID not found
    target = None
    if node_id in G:
        target = node_id
    else:
        for n, d in G.nodes(data=True):
            if d.get("label", "").lower() == node_id.lower():
                target = n
                break

    if target is None:
        return f"Node '{node_id}' not found."

    data = G.nodes[target]
    ans = (
        f"Node: {data.get('label')}\n"
        f"Type: {data.get('type')}\n"
        f"File: {data.get('file')}\n"
        f"Summary: {data.get('summary', 'No summary available.')}\n"
        f"Community: {data.get('community', 'N/A')}"
    )
    if is_partial:
        ans = "[PARTIAL GRAPH - Build still running]\n" + ans

    # Gap 2: record this node as served
    if _SESSION_TRACKING:
        _st.record_seen(node_id, tool="get_summary")
    return ans


def _list_communities(root: str = ".") -> str:
    """List detected architectural communities/modules."""
    G, is_partial = _load_graph(root)
    if G is None:
        return "Please run pruvagraph . first to build the graph."

    communities: dict[int, list[str]] = {}
    for node_id, data in G.nodes(data=True):
        c = data.get("community")
        if c is None:
            continue
        communities.setdefault(c, []).append(data.get("label", node_id))

    if not communities:
        return "No communities detected. Run graph build first."

    lines = [f"Detected {len(communities)} communities:\n"]
    for cid, members in sorted(communities.items()):
        sample = ", ".join(members[:5])
        more   = f" (+{len(members)-5} more)" if len(members) > 5 else ""
        lines.append(f"Community {cid} ({len(members)} nodes): {sample}{more}")
    ans = "\n".join(lines)
    if is_partial:
        ans = "[PARTIAL GRAPH - Build still running]\n" + ans
    return ans


def _get_cost_report(root: str = ".") -> str:
    """Return the cost report from the last run."""
    report_path = Path(root) / "pruvagraph-out" / "cost_report.json"
    if not report_path.exists():
        return "No cost report found. Run 'pruvagraph .' first."

    data = json.loads(report_path.read_text())
    return (
        f"PruvaGraph Cost Report\n"
        f"{'─'*40}\n"
        f"Files processed: {data.get('total_files_processed', 0):,}\n"
        f"Cache hits:      {data.get('cache_hits', 0):,}\n"
        f"Dedup projected: {data.get('dedup_projected', 0):,}\n"
        f"LLM calls made:  {data.get('llm_calls_made', 0):,}\n"
        f"Actual cost:     ${data.get('actual_cost_usd', 0):.6f}\n"
        f"Naive cost:      ${data.get('naive_cost_usd', 0):.4f}\n"
        f"Cost saved:      ${data.get('cost_saved_usd', 0):.4f} ({data.get('savings_pct', 0):.1f}%)\n"
        f"Run time:        {data.get('run_duration_seconds', 0):.1f}s"
    )


# ---------------------------------------------------------------------------
# D1: Graph Diff tool
# ---------------------------------------------------------------------------

def _get_graph_diff(root: str = ".") -> str:
    """Return last_diff.json contents as a formatted string."""
    from pruvagraph.graph_diff import load_diff
    out_dir = Path(root) / "pruvagraph-out"
    diff = load_diff(out_dir)
    if diff is None:
        return (
            "No diff available. The graph diff is generated automatically after each build.\n"
            "Run 'pruvagraph .' at least twice to see changes."
        )
    return diff.format()


# ---------------------------------------------------------------------------
# D2: Impact Analyzer tool
# ---------------------------------------------------------------------------

def _analyze_impact(node_id: str, root: str = ".", depth: int = 3) -> str:
    """Run impact analysis for a symbol — what breaks if it changes?"""
    out_dir    = Path(root) / "pruvagraph-out"
    graph_path = out_dir / "graph.json"
    if not graph_path.exists():
        return "Please run pruvagraph . first to build the graph."

    try:
        import networkx as nx
        G = nx.node_link_graph(json.loads(graph_path.read_text(encoding="utf-8")))
    except Exception as e:
        return f"Failed to load graph: {e}"

    # Load git intel if available
    git_intel = None
    try:
        from pruvagraph.git_intel import extract_git_intelligence
        intel = extract_git_intelligence(Path(root))
        if intel.get("available"):
            git_intel = intel
    except Exception:
        pass

    from pruvagraph.impact_analyzer import analyze_impact
    report = analyze_impact(G, node_id, depth=depth, git_intel=git_intel)
    return report.format("table")


# ---------------------------------------------------------------------------
# M1: List Packages tool
# ---------------------------------------------------------------------------

def _list_packages(root: str = ".") -> str:
    """Detect monorepo layout and list packages + cross-package edges."""
    from pruvagraph.monorepo import detect_monorepo, find_cross_package_edges
    layout = detect_monorepo(Path(root))
    if layout is None:
        return (
            f"'{root}' is not a detected monorepo.\n"
            "Supported: pnpm, Nx, Lerna, Turborepo, Rush, npm workspaces, Python, generic."
        )

    lines = [layout.summary(), ""]
    for pkg in layout.packages:
        lines.append(f"  • {pkg.name:<30}  {pkg.language:<12}  {pkg.root}")

    # Cross-package edges
    cross = find_cross_package_edges(layout.packages)
    if cross:
        lines.append(f"\nCross-package imports ({len(cross)}):")
        for src, tgt, rel in cross[:20]:
            lines.append(f"  {src} → {tgt}")
        if len(cross) > 20:
            lines.append(f"  ... and {len(cross) - 20} more")
    else:
        lines.append("\nNo cross-package imports detected.")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Arch5+6: Session Memory tools — GhostMemory (_remember / _recall)
# ---------------------------------------------------------------------------

def _remember(category: str, text: str, root: str = ".") -> str:
    """
    Persist a decision, task, or blocker to .pruvagraph/context-store.json.
    Entries are auto-injected into CLAUDE.md on the next 'pruvagraph .' build.
    """
    try:
        from pruvagraph.context_store import append_entry
        root_path = Path(root)
        append_entry(root_path, category, text)  # type: ignore[arg-type]
        return (
            f"✓ Remembered under '{category}': {text}\n"
            f"  → Will be injected into CLAUDE.md on next 'pruvagraph .' build.\n"
            f"  → Use recall() to retrieve all session memory."
        )
    except Exception as e:
        return f"Error storing memory: {e}"


def _recall(root: str = ".") -> str:
    """
    Return all persisted session memory as a markdown-formatted summary.
    Returns empty string with a hint if no memory has been stored yet.
    """
    try:
        from pruvagraph.context_store import format_for_injection, load_context
        root_path = Path(root)
        block = format_for_injection(root_path)
        if not block:
            ctx = load_context(root_path)
            total = sum(len(v) for v in ctx.values())
            if total == 0:
                return (
                    "No session memory stored yet.\n"
                    "Use remember(category, text) to persist decisions, tasks, or blockers."
                )
        return block
    except Exception as e:
        return f"Error reading session memory: {e}"


# ---------------------------------------------------------------------------
# DriftGuard tools — validate AI-suggested imports
# ---------------------------------------------------------------------------

def _validate_import(module: str, symbol: str | None = None, root: str = ".") -> str:
    """
    Check whether a Python module and optional symbol actually exist in
    the current environment.  Returns a human-readable verdict.
    """
    try:
        from pruvagraph.driftguard import validate_import
        r = validate_import(module, symbol, Path(root))
        if r.valid:
            ver = f" (v{r.actual_version})" if r.actual_version else ""
            sym_part = f".{symbol}" if symbol else ""
            return f"✓ {module}{sym_part} — valid{ver}"
        msg = f"⚠ {module}.{symbol or '*'} — INVALID"
        if r.suggestion:
            msg += f"\n  → {r.suggestion}"
        return msg
    except Exception as e:
        return f"Error validating import: {e}"


def _scan_suggestion(diff: str, root: str = ".") -> str:
    """
    Scan a unified diff for added import lines and validate each one
    against the current environment.
    """
    try:
        from pruvagraph.driftguard import scan_ai_suggestion
        results = scan_ai_suggestion(diff, Path(root))
        bad = [r for r in results if not r.valid]
        if not bad:
            return "✓ All imports in the suggestion are valid."
        lines = [f"⚠ {len(bad)} import issue(s) found:\n"]
        for r in bad:
            lines.append(f"  • {r.module}.{r.symbol or '*'}: {r.suggestion or 'not found'}")
        return "\n".join(lines)
    except Exception as e:
        return f"Error scanning suggestion: {e}"


# ---------------------------------------------------------------------------
# ContextLens tool handlers (v1.7.0)
# ---------------------------------------------------------------------------

def _get_active_context(root: str = ".") -> str:
    """ContextLens: return a session summary with per-tool token breakdown."""
    try:
        from pruvagraph.context_lens import get_active_context
        return get_active_context(root=root)
    except Exception as e:
        return f"Error reading context lens session: {e}"


def _measure_token_usage(root: str = ".") -> str:
    """ContextLens: return per-tool token cost totals for this session."""
    try:
        from pruvagraph.context_lens import measure_token_usage
        return measure_token_usage(root=root)
    except Exception as e:
        return f"Error measuring token usage: {e}"


def _trace_last_tool_calls(root: str = ".", n: int = 10) -> str:
    """ContextLens: return the last N tool calls with timestamps."""
    try:
        from pruvagraph.context_lens import trace_last_tool_calls
        return trace_last_tool_calls(root=root, n=n)
    except Exception as e:
        return f"Error tracing tool calls: {e}"


# ---------------------------------------------------------------------------
# TaskWeaver tool handlers (v1.8.0)
# ---------------------------------------------------------------------------

def _create_checkpoint(task_id: str, description: str,
                       files_changed: list | None = None,
                       root: str = ".") -> str:
    """TaskWeaver: create an agent step checkpoint with optional git micro-commit."""
    try:
        from pruvagraph.task_weaver import create_checkpoint
        return create_checkpoint(task_id, description, files_changed, root=root)
    except Exception as e:
        return f"Error creating checkpoint: {e}"


def _get_task_progress(task_id: str, root: str = ".") -> str:
    """TaskWeaver: return checkpoint DAG progress for a task."""
    try:
        from pruvagraph.task_weaver import get_task_progress
        return get_task_progress(task_id, root=root)
    except Exception as e:
        return f"Error getting task progress: {e}"


def _rollback_to_checkpoint(checkpoint_id: str, root: str = ".") -> str:
    """TaskWeaver: mark a checkpoint rolled_back and return the git restore command."""
    try:
        from pruvagraph.task_weaver import rollback_to_checkpoint
        return rollback_to_checkpoint(checkpoint_id, root=root)
    except Exception as e:
        return f"Error rolling back checkpoint: {e}"


def _list_checkpoints(task_id: str | None = None, root: str = ".") -> str:
    """TaskWeaver: list all checkpoints, optionally filtered by task_id."""
    try:
        from pruvagraph.task_weaver import list_checkpoints
        return list_checkpoints(task_id=task_id, root=root)
    except Exception as e:
        return f"Error listing checkpoints: {e}"


# ---------------------------------------------------------------------------
# Budget Governor tool handlers (v1.8.0)
# ---------------------------------------------------------------------------

def _check_budget(root: str = ".") -> str:
    """BudgetGovernor: return remaining token budget and status for this session."""
    try:
        from pruvagraph.budget_governor import check_budget
        return check_budget(root=root)
    except Exception as e:
        return f"Error checking budget: {e}"


# ---------------------------------------------------------------------------
# RulesForge tool handlers (v1.9.0)
# ---------------------------------------------------------------------------

def _get_applicable_rules(file_uri: str, root: str = ".") -> str:
    """RulesForge: return context-aware rules for the given file's layer."""
    try:
        from pruvagraph.rules_forge import get_applicable_rules
        return get_applicable_rules(file_uri, root=root)
    except Exception as e:
        return f"Error getting rules: {e}"


def _learn_from_accept(diff: str, description: str, root: str = ".") -> str:
    """RulesForge: store a pattern learned from a developer-accepted AI suggestion."""
    try:
        from pruvagraph.rules_forge import learn_from_accept
        return learn_from_accept(diff, description, root=root)
    except Exception as e:
        return f"Error learning from accept: {e}"


# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------
# D1 fix: All descriptions rewritten with "CALL THIS FIRST" pattern so
# Claude Code prioritises graph tools over built-in file-read tools.
TOOLS: list[dict[str, Any]] = [
    {
        "name": "query_graph",
        "description": (
            "CALL THIS FIRST before reading any source file, running grep, or using "
            "list_directory for any question about codebase structure, architecture, or "
            "dependencies. Answers natural language questions using a pre-built knowledge "
            "graph — 5×–71× cheaper in tokens than reading raw files. Fully offline, zero "
            "API cost. Examples: 'how does auth connect to the database?', "
            "'what modules does UserService depend on?', "
            "'where is payment processing handled?', "
            "'which files import the logger?'"
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "question": {"type": "string", "description": "Natural language question about the codebase"},
                "root":     {"type": "string", "description": "Project root directory (default: .)"},
            },
            "required": ["question"],
        },
    },
    {
        "name": "get_dependencies",
        "description": (
            "CALL THIS FIRST when asked what a module, class, or function imports or depends on. "
            "Returns the complete dependency graph from the pre-built knowledge graph — "
            "no file reads needed. Pass the node ID (e.g. 'auth.session.SessionManager') "
            "or a label. Always faster and cheaper than opening the file."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "node_id": {"type": "string", "description": "Node ID or label (e.g. 'auth.session.SessionManager')"},
                "root":    {"type": "string", "description": "Project root directory (default: .)"},
            },
            "required": ["node_id"],
        },
    },
    {
        "name": "find_callers",
        "description": (
            "CALL THIS FIRST when asked 'who calls X?', 'where is X used?', or "
            "'which files import Y?'. Returns all callers and importers of a function "
            "or class from the knowledge graph — much cheaper than grep across the whole "
            "codebase. Works on function names, class names, and node IDs."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "node_id": {"type": "string", "description": "Node ID, function name, or class name"},
                "root":    {"type": "string", "description": "Project root directory (default: .)"},
            },
            "required": ["node_id"],
        },
    },
    {
        "name": "get_summary",
        "description": (
            "CALL THIS FIRST when asked what a class, function, or file does. "
            "Returns a one-sentence summary + type + file location + community cluster "
            "from the knowledge graph. Zero file reads needed. "
            "Supports fuzzy matching — partial names and labels work."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "node_id": {"type": "string", "description": "Node ID, label, or partial name (fuzzy matching)"},
                "root":    {"type": "string", "description": "Project root directory (default: .)"},
            },
            "required": ["node_id"],
        },
    },
    {
        "name": "list_communities",
        "description": (
            "CALL THIS FIRST for architectural overview questions like 'what are the main modules?', "
            "'show me the high-level structure', or 'what does this codebase do?'. "
            "Lists all detected architectural clusters (communities) with member counts and "
            "representative symbols. Zero file reads."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string", "description": "Project root directory (default: .)"},
            },
        },
    },
    {
        "name": "cost_report",
        "description": (
            "Show the LLM cost analytics from the last pruvagraph build: files processed, "
            "cache hits, dedup savings, actual cost vs naive cost, and percentage saved. "
            "Also shows per-query token benchmarks if benchmark_mode was used."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string", "description": "Project root directory (default: .)"},
            },
        },
    },
    {
        "name": "get_graph_diff",
        "description": (
            "CALL THIS when asked 'what changed?', 'what’s new since last build?', or "
            "before starting a PR review. Shows added/removed/changed nodes and edges "
            "since the last 'pruvagraph .' run. Gives structural change context without "
            "reading individual files."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string", "description": "Project root directory (default: .)"},
            },
        },
    },
    {
        "name": "analyze_impact",
        "description": (
            "CALL THIS BEFORE making any change to a symbol, function, class, or file. "
            "Returns a risk-sorted list of all nodes that would be affected if this symbol "
            "changes — the blast radius. Use this to understand what might break without "
            "manually tracing every dependency chain."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "node_id": {
                    "type": "string",
                    "description": "Symbol name, class, file path, or node ID. Fuzzy matching — partial names work.",
                },
                "root":  {"type": "string", "description": "Project root directory (default: .)"},
                "depth": {
                    "type": "integer",
                    "description": "BFS depth limit (default 3). Higher = more transitive dependents.",
                    "default": 3,
                },
            },
            "required": ["node_id"],
        },
    },
    {
        "name": "list_packages",
        "description": (
            "CALL THIS FIRST for monorepo questions: 'what packages are in this repo?', "
            "'which packages depend on each other?'. Detects monorepo layout (pnpm, Nx, "
            "Lerna, Turborepo, Rush, npm workspaces, Python, generic) and lists all "
            "sub-packages with cross-package import edges. No file reads needed."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string", "description": "Monorepo root directory (default: .)"},
            },
        },
    },
    # ── Arch5+6: Session Memory (GhostMemory) ────────────────────────────────
    {
        "name": "remember",
        "description": (
            "Persist a decision, task, or blocker across Claude Code sessions so the "
            "next session doesn't start from zero. Stored entries are automatically "
            "injected into CLAUDE.md on the next 'pruvagraph .' build. "
            "category must be one of: 'decisions', 'tasks', 'blockers'. "
            "Examples: remember(category='decisions', text='Use Gemini for doc extraction — 40x cheaper') "
            "remember(category='tasks', text='Wire A5 global cache into pipeline.py')"
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "category": {
                    "type": "string",
                    "enum": ["decisions", "tasks", "blockers"],
                    "description": "Category to store under.",
                },
                "text": {
                    "type": "string",
                    "description": "What to remember — a decision made, task to do, or blocker encountered.",
                },
                "root": {"type": "string", "description": "Project root directory (default: .)"},
            },
            "required": ["category", "text"],
        },
    },
    {
        "name": "recall",
        "description": (
            "Retrieve all persisted session memory (decisions, tasks, blockers) from "
            "previous Claude Code sessions. Returns a markdown-formatted summary of "
            "everything stored via 'remember'. Call this at the start of a new session "
            "to resume where you left off without re-explaining context."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string", "description": "Project root directory (default: .)"},
            },
        },
    },
    # v1.6.0 — DriftGuard
    {
        "name": "validate_import",
        "description": (
            "DriftGuard: validate that a Python module and optional symbol (function, "
            "class, constant) actually exist in the current environment. Catches "
            "hallucinated imports and wrong-version API calls. Returns the installed "
            "version and a fuzzy-matched suggestion if the symbol is close to a real name."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "module": {
                    "type": "string",
                    "description": "Python module name (e.g. 'pandas', 'json', 'os.path').",
                },
                "symbol": {
                    "type": "string",
                    "description": "Symbol to check (e.g. 'read_csv'). Omit to just check the module.",
                },
                "root": {"type": "string", "description": "Project root directory (default: .)"},
            },
            "required": ["module"],
        },
    },
    {
        "name": "scan_suggestion",
        "description": (
            "DriftGuard: scan a unified diff (AI-suggested code change) for added import "
            "lines and validate each one against the actual installed packages. Reports "
            "any hallucinated or wrong-version imports with fuzzy-matched suggestions."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "diff": {
                    "type": "string",
                    "description": "Unified diff text of the AI suggestion.",
                },
                "root": {"type": "string", "description": "Project root directory (default: .)"},
            },
            "required": ["diff"],
        },
    },
    # v1.7.0 — ContextLens
    {
        "name": "get_active_context",
        "description": (
            "ContextLens: return a summary of what PruvaGraph tools have been called this "
            "session and how many tokens each consumed. Use this to understand what's already "
            "in context before making redundant tool calls. Shows per-tool token breakdown."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string", "description": "Project root directory (default: .)"},
            },
        },
    },
    {
        "name": "measure_token_usage",
        "description": (
            "ContextLens: measure the total estimated token cost of all PruvaGraph tool calls "
            "made this session, broken down by tool. Helps identify which tools are consuming "
            "the most context budget so you can avoid redundant calls."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string", "description": "Project root directory (default: .)"},
            },
        },
    },
    {
        "name": "trace_last_tool_calls",
        "description": (
            "ContextLens: return the last N PruvaGraph tool calls made in this session with "
            "their names, estimated token cost, and timestamps. Default N=10. Use this to "
            "avoid repeating recent tool calls that already populated the context window."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string", "description": "Project root directory (default: .)"},
                "n":    {"type": "integer", "description": "Number of recent calls to return (default: 10)"},
            },
        },
    },
    # v1.8.0 — TaskWeaver
    {
        "name": "create_checkpoint",
        "description": (
            "TaskWeaver: save the current agent step as a checkpoint. Creates a git "
            "micro-commit (if inside a git repo) and records which files were changed. "
            "Use at the end of each significant step so a failed run can resume from "
            "this point instead of restarting from scratch. Returns the checkpoint ID "
            "and git SHA."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id":     {"type": "string", "description": "Label for this agent task (e.g. 'implement-auth')."},
                "description": {"type": "string", "description": "What was done at this step."},
                "files_changed": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of relative file paths changed at this step.",
                },
                "root": {"type": "string", "description": "Project root directory (default: .)"},
            },
            "required": ["task_id", "description"],
        },
    },
    {
        "name": "get_task_progress",
        "description": (
            "TaskWeaver: show the full checkpoint history for a task — step count, "
            "cumulative token spend, per-step description and status. Use to understand "
            "what an agent has already done before continuing a partially-completed task."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string", "description": "Task label to query."},
                "root":    {"type": "string", "description": "Project root directory (default: .)"},
            },
            "required": ["task_id"],
        },
    },
    {
        "name": "rollback_to_checkpoint",
        "description": (
            "TaskWeaver: mark a checkpoint (and all subsequent steps) as rolled back. "
            "Returns the git SHA at that point and the exact git command needed to restore "
            "the working tree. Does NOT automatically run git reset — that requires explicit "
            "user consent. Review the diff before executing the returned command."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "checkpoint_id": {"type": "string", "description": "UUID of the checkpoint to roll back to."},
                "root":          {"type": "string", "description": "Project root directory (default: .)"},
            },
            "required": ["checkpoint_id"],
        },
    },
    {
        "name": "list_checkpoints",
        "description": (
            "TaskWeaver: list all agent checkpoints, optionally filtered to a specific "
            "task. Shows checkpoint IDs, descriptions, status (active/rolled_back), and "
            "git SHAs. Use to find a checkpoint_id before calling rollback_to_checkpoint."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string", "description": "Filter to this task only (optional)."},
                "root":    {"type": "string", "description": "Project root directory (default: .)"},
            },
        },
    },
    # v1.8.0 — Budget Governor
    {
        "name": "check_budget",
        "description": (
            "BudgetGovernor: check remaining token budget for this session. Returns "
            "the cap, amount spent so far, remaining tokens, percentage used, and a "
            "status (OK / WARNING at 80% / EXCEEDED at 100%). Call this before expensive "
            "operations to avoid overspending. Set the budget with the CLI: "
            "`pruvagraph budget set <tokens>`."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "root": {"type": "string", "description": "Project root directory (default: .)"},
            },
        },
    },
    # v1.9.0 — RulesForge
    {
        "name": "get_applicable_rules",
        "description": (
            "RulesForge: given a file URI, detect its architectural layer (api/ui/test/util/ "
            "config) using AST analysis and return the context-appropriate AI coding rules "
            "for that layer. Unlike static .cursorrules files, these rules change based on "
            "what file the agent is currently working on. Call this at the start of any "
            "file-editing session to get layer-specific constraints."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_uri":  {"type": "string", "description": "Absolute or relative path to the file being edited."},
                "root":      {"type": "string", "description": "Project root directory (default: .)"},
            },
            "required": ["file_uri"],
        },
    },
    {
        "name": "learn_from_accept",
        "description": (
            "RulesForge: store a coding pattern learned from a developer-accepted AI suggestion. "
            "Provide the diff and a plain-English description of the pattern. RulesForge infers "
            "the target layer from the diff's file paths and appends the pattern to the layer's "
            "learned-rules list, which will appear in future get_applicable_rules calls for "
            "files in that layer."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "diff":        {"type": "string", "description": "The diff text of the accepted change."},
                "description": {"type": "string", "description": "Plain-English description of the pattern to learn."},
                "root":        {"type": "string", "description": "Project root directory (default: .)"},
            },
            "required": ["diff", "description"],
        },
    },
]

# Settings-gating: remove disabled tools from MCP discovery list.
# Clients will not see disabled tools in their tool palette at all.
if _DISABLED_TOOLS:
    TOOLS = [t for t in TOOLS if t["name"] not in _DISABLED_TOOLS]


TOOL_HANDLERS = {
    "query_graph":      lambda args: _query_graph(args["question"], args.get("root", ".")),
    "get_dependencies": lambda args: _get_dependencies(args["node_id"], args.get("root", ".")),
    "find_callers":     lambda args: _find_callers(args["node_id"], args.get("root", ".")),
    "get_summary":      lambda args: _get_summary(args["node_id"], args.get("root", ".")),
    "list_communities": lambda args: _list_communities(args.get("root", ".")),
    "cost_report":      lambda args: _get_cost_report(args.get("root", ".")),
    # v1.3.0
    "get_graph_diff":   lambda args: _get_graph_diff(args.get("root", ".")),
    "analyze_impact":   lambda args: _analyze_impact(
                            args["node_id"],
                            args.get("root", "."),
                            int(args.get("depth", 3)),
                        ),
    "list_packages":    lambda args: _list_packages(args.get("root", ".")),
    # v1.5.0 — GhostMemory / session memory
    "remember":         lambda args: _remember(
                            args["category"],
                            args["text"],
                            args.get("root", "."),
                        ),
    "recall":           lambda args: _recall(args.get("root", ".")),
    # v1.6.0 — DriftGuard
    "validate_import":  lambda args: _validate_import(
                            args["module"],
                            args.get("symbol"),
                            args.get("root", "."),
                        ),
    "scan_suggestion":  lambda args: _scan_suggestion(
                            args["diff"],
                            args.get("root", "."),
                        ),
    # v1.7.0 — ContextLens
    "get_active_context":    lambda args: _get_active_context(args.get("root", ".")),
    "measure_token_usage":   lambda args: _measure_token_usage(args.get("root", ".")),
    "trace_last_tool_calls": lambda args: _trace_last_tool_calls(
                                args.get("root", "."),
                                int(args.get("n", 10)),
                             ),
    # v1.8.0 — TaskWeaver
    "create_checkpoint":      lambda args: _create_checkpoint(
                                  args["task_id"],
                                  args["description"],
                                  args.get("files_changed"),
                                  args.get("root", "."),
                              ),
    "get_task_progress":      lambda args: _get_task_progress(
                                  args["task_id"],
                                  args.get("root", "."),
                              ),
    "rollback_to_checkpoint": lambda args: _rollback_to_checkpoint(
                                  args["checkpoint_id"],
                                  args.get("root", "."),
                              ),
    "list_checkpoints":       lambda args: _list_checkpoints(
                                  args.get("task_id"),
                                  args.get("root", "."),
                              ),
    # v1.8.0 — Budget Governor
    "check_budget":           lambda args: _check_budget(args.get("root", ".")),
    # v1.9.0 — RulesForge
    "get_applicable_rules":   lambda args: _get_applicable_rules(
                                  args["file_uri"],
                                  args.get("root", "."),
                              ),
    "learn_from_accept":      lambda args: _learn_from_accept(
                                  args["diff"],
                                  args["description"],
                                  args.get("root", "."),
                              ),
}

# Apply settings-gating: remove disabled tools from dispatch table and discovery list.
# A disabled tool's handler is replaced with an explicit error response so clients
# that hardcode the tool name get a clear message rather than a silent failure.
if _DISABLED_TOOLS:
    for _dt in _DISABLED_TOOLS:
        if _dt in TOOL_HANDLERS:
            _disabled_name = _dt  # capture for lambda closure
            TOOL_HANDLERS[_disabled_name] = (
                lambda args, _n=_disabled_name: (
                    f"### Tool Disabled\n\n"
                    f"The tool `{_n}` is disabled by workspace settings.\n"
                    f"Enable it in VS Code Settings → PruvaGraph → Modules."
                )
            )



def _dispatch(tool_name: str, args: dict, handler_fn) -> str:
    """Call a tool handler, auto-log to ContextLens, and record budget spend.

    Single point where:
      1. The handler is called
      2. ContextLens records the call (tool_name, args, result, tokens)
      3. BudgetGovernor records the token spend against the session budget
    All side-effects are non-blocking — any exception is silently swallowed
    so ContextLens/BudgetGovernor issues never break a tool call.
    """
    result: str = handler_fn(args)
    root = args.get("root", ".")
    token_est = len(result) // 4
    try:
        from pruvagraph.context_lens import record_tool_call
        record_tool_call(tool_name, args, result, root=root)
    except Exception:
        pass  # ContextLens logging must never break a tool call
    try:
        from pruvagraph.budget_governor import record_spend
        record_spend(token_est, tool_name, root=root)
    except Exception:
        pass  # Budget recording must never break a tool call
    return result


async def run_stdio_server() -> None:
    """Run MCP server over stdio (for Claude Code and most IDE integrations)."""
    if not _MCP_AVAILABLE:
        print("Error: 'mcp' package not installed. Run: pip install mcp", file=sys.stderr)
        sys.exit(1)

    server = Server("pruvagraph")

    @server.list_tools()
    async def handle_list_tools(req: ListToolsRequest) -> ListToolsResult:
        return ListToolsResult(tools=[Tool(**t) for t in TOOLS])

    @server.call_tool()
    async def handle_call_tool(req: CallToolRequest) -> CallToolResult:
        handler = TOOL_HANDLERS.get(req.params.name)
        if handler is None:
            return CallToolResult(
                content=[TextContent(type="text", text=f"Unknown tool: {req.params.name}")]
            )
        # Gap 2: tick the session turn counter on every MCP tool invocation
        if _SESSION_TRACKING:
            _st.tick()
        try:
            args = req.params.arguments or {}
            result = _dispatch(req.params.name, args, handler)
            return CallToolResult(content=[TextContent(type="text", text=result)])
        except Exception as e:
            return CallToolResult(
                content=[TextContent(type="text", text=f"Error: {e}")]
            )

    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream, write_stream,
            InitializationOptions(
                server_name="pruvagraph",
                server_version="1.9.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )


def write_ide_configs(
    root: Path = Path("."),
    disabled_modules: list[str] | None = None,
) -> dict[str, Path]:
    """
    Write MCP config files for all major IDEs.

    Args:
        root:             Project root directory.
        disabled_modules: List of module keys to disable via env var.
                          When set, PRUVAGRAPH_DISABLED_MODULES is written
                          into the server's env block in all IDE configs.

    Returns:
        Dict of {ide_name: config_path} for all files written.
    """
    # Find the pruvagraph executable
    import shutil
    exe = shutil.which("pruvagraph") or "python -m pruvagraph.mcp_server"
    server_cmd = [exe, "mcp-serve"] if shutil.which("pruvagraph") else ["python", "-m", "pruvagraph.mcp_server"]

    server_env: dict[str, str] = {}
    if disabled_modules:
        server_env["PRUVAGRAPH_DISABLED_MODULES"] = ",".join(disabled_modules)

    mcp_config = {
        "mcpServers": {
            "pruvagraph": {
                "command": server_cmd[0],
                "args": server_cmd[1:],
                "env": server_env,
                "description": "PruvaGraph knowledge graph — query your codebase",
            }
        }
    }

    written: dict[str, Path] = {}

    # Claude Code: ~/.claude/mcp_config.json
    claude_config = Path.home() / ".claude" / "mcp_config.json"
    _merge_json(claude_config, mcp_config)
    written["Claude Code"] = claude_config

    # Cursor: <project>/.cursor/mcp.json
    cursor_config = root / ".cursor" / "mcp.json"
    cursor_config.parent.mkdir(parents=True, exist_ok=True)
    _merge_json(cursor_config, mcp_config)
    written["Cursor"] = cursor_config

    # VS Code / Windsurf: <project>/.vscode/mcp.json
    vscode_config = root / ".vscode" / "mcp.json"
    vscode_config.parent.mkdir(parents=True, exist_ok=True)
    _merge_json(vscode_config, mcp_config)
    written["VS Code"] = vscode_config

    # CLAUDE.md: instructions for Claude Code context window
    claude_md = root / "CLAUDE.md"
    _write_claude_md(claude_md)
    written["CLAUDE.md"] = claude_md

    return written


def _merge_json(path: Path, new_data: dict) -> None:
    """Merge new_data into existing JSON file (or create it)."""
    existing = {}
    if path.exists():
        try:
            existing = json.loads(path.read_text())
        except Exception:
            pass
    merged = {**existing}
    for k, v in new_data.items():
        if isinstance(v, dict) and isinstance(merged.get(k), dict):
            merged[k] = {**merged[k], **v}
        else:
            merged[k] = v
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(merged, indent=2))


def _write_claude_md(path: Path) -> None:
    content = """\
# PruvaGraph — Codebase Knowledge Graph

This project uses PruvaGraph to maintain a knowledge graph of the codebase.

## Available MCP Tools (v1.9.0 — 23 tools)

| Tool                    | Usage                                              |
|-------------------------|----------------------------------------------------|
| `query_graph`           | Ask anything about the codebase in natural language |
| `get_dependencies`      | Find what a module/function depends on              |
| `find_callers`          | Find who calls a function                           |
| `get_summary`           | Get a one-sentence summary of any node              |
| `list_communities`      | See architectural module groupings                  |
| `cost_report`           | View LLM cost savings from last build               |
| `get_graph_diff`        | What changed since last build? (D1)                 |
| `analyze_impact`        | What breaks if X changes? Risk-sorted list (D2)     |
| `list_packages`         | Monorepo: list packages + cross-package edges (M1)  |
| `remember`              | Persist a decision/task/blocker across sessions     |
| `recall`                | Retrieve all persisted session memory               |
| `validate_import`       | DriftGuard: check if a module/symbol exists         |
| `scan_suggestion`       | DriftGuard: scan a diff for invalid imports         |
| `get_active_context`    | ContextLens: session summary + token breakdown      |
| `measure_token_usage`   | ContextLens: per-tool token cost this session       |
| `trace_last_tool_calls` | ContextLens: recent tool call history               |
| `create_checkpoint`     | TaskWeaver: save agent step with git micro-commit   |
| `get_task_progress`     | TaskWeaver: show checkpoint DAG for a task          |
| `rollback_to_checkpoint`| TaskWeaver: advisory rollback with git command      |
| `list_checkpoints`      | TaskWeaver: list all checkpoints                    |
| `check_budget`          | BudgetGovernor: remaining token budget this session |
| `get_applicable_rules`  | RulesForge: context-aware rules for current file    |
| `learn_from_accept`     | RulesForge: capture rule from accepted AI suggestion|

## Rebuilding the Graph

```bash
pruvagraph .              # full rebuild
pruvagraph . --update     # incremental (changed files only)
pruvagraph . --dry-run    # estimate cost first
pruvagraph . --monorepo   # monorepo: build per-package graphs
```

## Diff & Impact

```bash
pruvagraph diff                     # what changed since last build?
pruvagraph impact SessionManager   # what breaks if SessionManager changes?
pruvagraph impact auth.py --depth 4
```

## Session Memory

```
remember(category="decisions", text="Use Gemini for doc extraction — 40x cheaper")
remember(category="tasks", text="Wire preinjection into pipeline.py")
recall()   # retrieve everything stored across sessions
```

## Graph Location
Output: `pruvagraph-out/`
  - `graph.json`        — full knowledge graph
  - `last_diff.json`    — delta from last build (D1)
  - `cost_report.json`  — cost analytics
  - `GRAPH_REPORT.md`   — architectural summary
  - `graph.html`        — interactive visualisation
"""
    if not path.exists():
        path.write_text(content, encoding="utf-8")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def run_server() -> None:
    """
    Public entry point for the `pruvagraph serve` CLI subcommand.

    Used by: `claude mcp add --transport stdio pruvagraph -- pruvagraph serve`
    """
    import asyncio
    asyncio.run(run_stdio_server())


if __name__ == "__main__":
    import asyncio

    asyncio.run(run_stdio_server())
